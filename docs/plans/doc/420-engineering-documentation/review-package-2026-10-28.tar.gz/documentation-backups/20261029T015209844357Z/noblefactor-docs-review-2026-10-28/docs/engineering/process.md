---
title: "Engineering process"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Engineering process

## Work philosophy

> The shape of a job changes. It always changes. The process and tooling we put in place must support the inevitable churn. We will have succeeded, when we hear from devs that the engineering systems support the work and its evolution.
>
> — David Noble

Changes to scope, design and implementation are expected. Make the proposed change and its consequences easy to understand, review and carry through the affected records. Approval keeps the owner informed and in control; it must not become a reason to conceal discoveries or resist necessary change.

## Roles and responsibilities

This engineering workflow uses RACI responsibilities under these names:

| Role            | RACI equivalent | Responsibility                                                                             |
| --------------- | --------------- | ------------------------------------------------------------------------------------------ |
| **Owner**       | Accountable     | Owns the outcome and has final decision authority.                                         |
| **Reviewer**    | Consulted       | Challenges proposals, evaluates results, and advises the Owner.                            |
| **Participant** | Responsible     | Performs the work and provides evidence of its quality and completion.                     |
| **Observer**    | Informed        | Follows the work and keeps the Owner informed of progress, decisions, risks, and findings. |

The engineer is the Owner. Agents serve as Observers, Reviewers, or Participants.

In the proposed arrangement, the agents at the top support the Owner through observation and review. These responsibilities may be divided among several agents, including separate Reviewers for design, planning, and code. The worker agents are Participants, each assigned a schedule defining its mission.

Participants are expected to exercise engineering judgment and speak their minds. They should question assumptions, identify risks, propose alternatives, and challenge designs, plans, and code—including proposals from the Owner or Reviewers. Their responsibility is to produce high-quality outcomes, not merely execute instructions or create the appearance of progress.

Participants should develop and demonstrate the judgment needed to serve as Reviewers and Observers. Review authority is entrusted explicitly; it is not assumed. The Owner retains accountability and final decision authority.

## Define the promised outcome

Work begins with an issue describing the problem and intended result. Place it within the applicable feature and epic, and within an approved schedule when executing scheduled work. Consult [Work organization](work-organization.md) for definitions, commitments and discoveries.

The owner must be able to understand the design and implementation they will have at the end before implementation starts. A list of activities alone is insufficient.

## Prepare and review

The sequence is issue → issue-bound branch and worktree → committed plan → substantive owner review → implementation. Git and commit approval remain separate obligations for owner-supervised agents; authorization to draft a plan is not a command grant.

Prepare the [required assets](work-assets.md): issue, plan and explicit design-impact assessment. Link design documents when changes are required; otherwise record why no design change is needed. Describe resulting behavior, implementation approach, interfaces, tradeoffs, scope boundaries, acceptance criteria and verification evidence.

Review is an engineering exchange. Agents must challenge assumptions, explain disagreements and alternatives, and engage with the owner's challenges until the proposed outcome is understood and approved. Agreement is not a substitute for reasoning. Record the approved revision and relevant decisions.

## Implement the approved work

Implementation starts only after approval of the plan and applicable design changes. Make routine choices within approved behavior, architecture, scope and verification commitments without requesting approval for each choice.

If a finding calls for departure, pause affected work. Explain the discrepancy, proposed change, alternatives and effect on the promised outcome. Obtain owner approval before proceeding with that departure. Update the approved records; do not rewrite them after the fact to make an unauthorized implementation appear planned.

All development occurs in worktrees. Canonical clones are read-only for development. Follow [Coding standards](../standards/coding/index.md). Check changes as made, correct failures, and update affected plans, design/status documents and user documentation in the commit that changes what they describe.

## Verify and review results

Evaluate the approved acceptance criteria with evidence identifying the revision/artifact, environment, method, time and result. Report failures and limitations. Build success, tests, merge, deployment and operation on the user's real path establish different things.

Record implementation, merge, deployment and verification separately. The plan specifies which milestones this issue requires. For changes to deployed layer paths, completion includes convergence, resolving deployed links, removing authorized obsolete artifacts and validating the actual deployed command.

Use [Completion review](../templates/completion-review.md) to compare delivered results with the approved outcome. Pending work remains visible. The precise plan-status and GitHub-closure transitions remain [O03](review/open-decisions.md); do not mark an issue complete based on merge alone.

## Pull request and integration

A worktree serves one PR and may cover multiple approved issues. Every PR resolves identified work. The existing rule that all its issues must be resolved before opening a PR needs the milestone distinction in [O03](review/open-decisions.md); implementation readiness cannot prove a future merge or deployment.

Preserve current PR requirements: review deltas, stage explicit verified paths, leave no unstaged tracked modifications, run the actual repository gates, wait for required checks, inspect mergeability, integrate without rebase, squash merge, disclose assistance and verify required trailers. Record PR time-open and scheduled-issue transitions as the merge lands. Elapsed time is not effort.

[The PR procedure](procedures/pull-request.md) retains the detailed existing script specification for review. This draft does not replace it with a new script or authorize a run. The global one-PR/no-write scope remains unresolved under [O01](review/open-decisions.md).

## Completion and progression

For owner-supervised work, the owner approves issue completion after reviewing results and evidence before the worker advances. The owner may instead authorize unattended progression through a defined portion of a schedule. That authorization does not waive design, plan, schedule-amendment, conversation or command approvals.

Unattended progression stops on a blocker, a required departure from approved commitments, or inability to demonstrate an acceptance criterion. Record current state and bring the decision to the owner. A controller cannot turn a worker's completion report into a broader grant.

## Preserve and clean up

Blocked work is preserved by default. Abandonment or deletion is an explicit decision. After an approved merge or abandonment, promptly remove the worktree and its sibling PR script and close the branch using the supported cleanup procedure. Identify lingering assets when noticed.

Ensure needed post-merge obligations and evidence remain recorded outside any worktree that is removed. Cleanup does not itself demonstrate deployment, verification or completion.
