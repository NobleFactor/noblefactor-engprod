---
title: "Completion review template"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Completion review template

## Role assignments

Identify the [roles](../engineering/process.md#roles-and-responsibilities) for this work, directly or by linking to its schedule's current assignments:

- **Owner:** [accountable engineer].
- **Participants:** [agents/people performing the work and their scope].
- **Reviewers:** [consulted reviewers; identify design, planning, and code responsibilities as applicable].
- **Observers:** [informed agents/people following the work].

## Approved outcome

[Issue, schedule, plan/design revision and approved departures.]

## Delivered result

[Concrete behavior and implementation now present.]

## Acceptance evidence

| Criterion | Expected | Observed | Evidence and target | Result |
| --- | --- | --- | --- | --- |
| [criterion] | [result] | [observation] | [revision/environment/method/time/link] | [pass/fail/pending] |

## Milestones

[Implementation, merge, deployment and verification separately; required/not required with approved rationale; actual evidence.]

## Remaining obligations and limitations

[Unfinished work, failures, uncertainties, blocker, preserved work location and required decision.]

## Review and progression

[Owner's completion approval, or exact prior unattended-progression grant covering this issue; stop-condition assessment.]

## Records and cleanup

[Schedule state, issue closure reason, document updates and worktree/script cleanup; do not claim completion of pending operations.]
