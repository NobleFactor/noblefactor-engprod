---
title: "Issue template"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Issue template

## Role assignments

Identify the [roles](../engineering/process.md#roles-and-responsibilities) for this work, directly or by linking to its schedule's current assignments:

- **Owner:** [accountable engineer].
- **Participants:** [agents/people performing the work and their scope].
- **Reviewers:** [consulted reviewers; identify design, planning, and code responsibilities as applicable].
- **Observers:** [informed agents/people following the work].

## Problem and intended outcome

[What is wrong or missing; the observable result sought.]

## Scope and relationships

[Task or bug; owning feature/epic and repository; schedule/position; dependencies and overlaps. Retain required current metadata markers until field authority is decided.]

## Architecture and design impact

[Changes required and design links, or explicit no-change conclusion with reasons.]

## Acceptance

[Outcome criteria; link to detailed plan evidence.]

## Plan and design documents

| Kind | Document |
| --- | --- |
| Plan | Not yet opened |

[Add one linked design row per applicable document.]
