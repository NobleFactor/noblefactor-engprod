---
title: "Bash standards"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Bash standards

## Source and dependencies

Retain the existing Declare-BashScript requirement for Bash commands. A Git hook sources nothing: it is Git configuration executed from the hooks path, not an ordinary command. Project placement and dependency boundaries are defined in [Work assets](../../engineering/work-assets.md).

Declare the helper with `# shellcheck source=Declare-BashScript` directly above the source line. Use the helper's filename rather than a source-directive path. Configure the lint search path to the engprod source directory, deployed helper or pinned dependency checkout as appropriate. A missing mandatory helper must fail closed rather than allow the rest of the command to run without its error handling.

## Form and validation

Retain shfmt's four-space indentation and switch-case indentation, and ShellCheck following sourced files. Preserve argument boundaries and native failure results. Run repository-provided checks rather than an approximation of CI. Formatting validity does not prove intended behavior.

The current lint tool versions, flags and platform prerequisites are implementation details to inventory in the later tooling discussion. Existing PR Bash examples do not source Declare-BashScript; that scope conflict remains [O08](../../engineering/review/open-decisions.md).
