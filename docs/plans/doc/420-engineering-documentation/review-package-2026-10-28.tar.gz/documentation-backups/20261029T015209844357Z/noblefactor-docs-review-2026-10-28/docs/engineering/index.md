---
title: "Engineering documentation"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Engineering documentation

## Purpose and authority

The authoritative home of organization-wide engineering process, standards and templates is `noblefactor-engprod`. Repository instructions link to shared requirements and state local requirements or approved exceptions. Each shared requirement has one authoritative home.

This draft reorganizes existing requirements and incorporates the owner's recorded decisions. Conflicts not resolved by those decisions remain explicit in [Open decisions](review/open-decisions.md). Publication and cutover from existing documents require review; copying a requirement does not resolve a conflict.

## Applicability

- **Everyone:** engineers and agents performing engineering work.
- **All agents:** automated participants, including controllers, workers and sub-agents.
- **Owner-supervised agents:** agents working within the owner's personal workflow. The owner is the person approving missions, outcomes and departures.

Shared process and standards apply to everyone unless a section declares a narrower audience. Agent operation labels its additional duties. A repository variation names the affected requirement, its scope, rationale and approval. It does not silently weaken a shared requirement.

## Roles

The engineer is the Owner; agents serve as Observers, Reviewers, or Participants. See [Roles and responsibilities](process.md#roles-and-responsibilities) for the authoritative definitions and expectations.

## Reading path and ownership

| Document                                                | Owns                                                     |
| ------------------------------------------------------- | -------------------------------------------------------- |
| [Process](process.md)                                   | Workflow transitions and approvals                       |
| [Work organization](work-organization.md)               | Issues, schedules, scope, ordering and dependencies      |
| [Work assets](work-assets.md)                           | Required records, locations, relationships and lifecycle |
| [Agent operation](agent-operation.md)                   | Agent-specific authority, visibility and coordination    |
| [Release and recovery](release-and-recovery.md)         | Additional release and recovery requirements             |
| [Documentation standard](../standards/documentation.md) | Document form, metadata and maintenance                  |
| [Coding standards](../standards/coding/index.md)        | Shared and language-specific code requirements           |
| [Procedures](procedures/index.md)                       | Mechanics for satisfying requirements                    |
| [Templates](../templates/index.md)                      | Structures for recording required information            |

The process says when a step may occur; standards say what must be true; procedures say how to perform it. Templates introduce no policy. Existing incidents remain rationale and regression examples.

Unresolved scope questions do not grant exceptions. Surface them to the owner before affected work. Historical source material is evidence of previous requirements, not permission to choose between conflicting instructions.
