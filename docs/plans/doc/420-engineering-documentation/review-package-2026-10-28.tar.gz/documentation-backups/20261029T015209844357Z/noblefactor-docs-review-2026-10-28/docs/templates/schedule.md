---
title: "Schedule template"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Schedule template

## Role assignments

Identify the [roles](../engineering/process.md#roles-and-responsibilities) for this work, directly or by linking to its schedule's current assignments:

- **Owner:** [accountable engineer].
- **Participants:** [agents/people performing the work and their scope].
- **Reviewers:** [consulted reviewers; identify design, planning, and code responsibilities as applicable].
- **Observers:** [informed agents/people following the work].

## Deliverable

Before: [what the owner has].

After: [what the owner will have when all scheduled issues are complete].

## Mission and ownership

Owner: [person]. Worker assignment: [identity]. Scope and exclusions: [description]. Approved schedule revision: [reference].

## Ordered issues

| Position | Issue | Next | Waits on |
| --- | --- | --- | --- |
| 1 | [repository-qualified issue and meaning] | [state; worktree/PR or next action] | [dependency or none] |

The proposed header removes the old terminology. Existing report behavior is not changed by this draft; final schema/compatibility is a later decision.

## Overlap and coordination

[Other schedules, shared issues/code, responsibilities, approved conversation references.]

## Amendments

[Proposal, effect on deliverable/order/scope, owner approval and revision.]

## Progression authority

[Default owner completion review, or explicit authorized issue range; conditions and stop triggers.]
