---
title: "Design template"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Design template

## Role assignments

Identify the [roles](../engineering/process.md#roles-and-responsibilities) for this work, directly or by linking to its schedule's current assignments:

- **Owner:** [accountable engineer].
- **Participants:** [agents/people performing the work and their scope].
- **Reviewers:** [consulted reviewers; identify design, planning, and code responsibilities as applicable].
- **Observers:** [informed agents/people following the work].

## Purpose and resulting system

[The enduring architecture and behavior after the change.]

## Context and requirements

[Problem, constraints, linked issues/plans and current system.]

## Structure and behavior

[Components, responsibilities, data flow, state, interfaces, errors and boundaries.]

## Alternatives and tradeoffs

[Options considered, challenged assumptions, rationale and consequences.]

## Operational consequences

[Compatibility where applicable, security, deployment, recovery and observability.]

## Decision and approval

[Owner's understood/approved proposal and revision; unresolved questions.]

## Implementation relationship

[Plans delivering the design; identify which parts are proposed, implemented and verified. Keep execution steps in plans.]
