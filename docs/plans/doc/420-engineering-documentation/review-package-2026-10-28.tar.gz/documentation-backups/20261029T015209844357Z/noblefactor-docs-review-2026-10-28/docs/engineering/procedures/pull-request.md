---
title: "Pull request procedure — retained specification"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Pull request procedure — retained specification

## Review boundary

The [existing PR script specification](../review/sources/pr-script-template.txt) is preserved verbatim for detailed review: Unix and Windows forms, staging/preflight, CI and merge gates, message/trailer composition, time-open calculation, guarded schedule writes, readback, cleanup and final verification.

Its historical terminology and paths are not new approved definitions. Apply the draft process's issue terminology and approval boundaries. A new executable template is deferred until unresolved questions are answered; this source is not a ready-to-run script.

Retain explicit staging; never stage the whole tree indiscriminately. Verify generated path lists, use safe literal multi-line message construction, check native exit results, and run the repository's actual CI-equivalent entry point. Do not bypass hooks. Check actual CI and mergeability rather than inferring them from a local run.

Retain no rebase, squash merge without automatic delete-branch, target integration before push and canonical-clone sync after cleanup. Preserve the existing required assistance/sign-off disclosure and verify the landed message, subject to the unresolved agent-name question.

Record PR time-open from GitHub timestamps, not estimated effort. Record scheduled-issue state when the merge lands, with stale-read protection and readback, before removing the worktree/script. Where a record changed since inspection, stop and reconcile rather than overwrite it.

The owner runs the reviewed script unless explicitly authorizing one agent run. Report a failed run and diagnose before a proposed retry. An end-of-PR issue report is printed only when requested, scoped to the work served.
