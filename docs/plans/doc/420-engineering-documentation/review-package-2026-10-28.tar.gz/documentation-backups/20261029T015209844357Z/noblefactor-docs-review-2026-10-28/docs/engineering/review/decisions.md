---
title: "Decisions established in review"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Decisions established in review

These decisions are recorded from the owner's approvals in this conversation. Approval of structure and principles does not imply approval of the draft's exact wording or new proposed fields.

1. Explicitly distinguish requirements for everyone, all agents and owner-supervised agents.
2. A persistent worker session is assigned a schedule and works through its issues.
3. Controller–worker communication is authorized within an approved assignment and observable. Sub-agents may help freely within a worker boundary on approved work.
4. Nothing happens outside the owner's knowledge. Activity must be visible and conversations fully available for live monitoring and intervention.
5. Cross-worker conversation approval covers named participants and a topic until the conversation ends; changing either requires renewed approval.
6. Surface schedule overlap before changing scope, ownership or order.
7. Record implementation, merge, deployment and verification as separate milestones; define which the issue requires.
8. Committed schedule changes require owner approval, including changes needed to address blockers.
9. Preserve blocked work and record its state; abandonment/deletion is an explicit decision.
10. Every scheduled issue records design impact, including an explicit no-change determination where applicable.
11. Plans own execution and verification. Designs own enduring architecture and decisions.
12. Releases and hotfixes follow the shared process with explicit approved exceptions.
13. Organization-wide authority resides in noblefactor-engprod; repository instructions link to it and state local requirements or approved exceptions.
14. Before implementation, the owner understands and approves the resulting design and implementation. Agents challenge assumptions and engage with challenges substantively.
15. Departures from approved commitments pause affected work for explanation and approval.
16. Routine implementation choices preserving approved commitments need no separate approval.
17. Plans define observable acceptance criteria and evidence before implementation.
18. The owner approves issue completion before progression unless explicitly authorizing unattended progression for a defined schedule portion.
19. Unattended progression stops on blockers, necessary departures or insufficient acceptance evidence; other approval requirements remain.
20. Preserve existing requirements unless these decisions change them; mark unresolved conflicts for review.
21. Use issue for scheduled work throughout. The former term appears only in preserved historical sources or discussion of migration.
22. The proposed document structure and ownership split are approved, with the issue terminology change.
23. Preserve the owner's work philosophy in the documentation: “The shape of a job changes. It always changes. The process and tooling we put in place must support the churn. We will have failed, if its hard to change the shape of a job.”

24. Use the RACI role names Owner (Accountable), Reviewer (Consulted), Participant (Responsible), and Observer (Informed). The engineer is the Owner. Agents serve as Observers/Reviewers or Participants. Participants speak their minds, challenge proposals and develop the judgment needed for review; review authority is explicitly entrusted.
