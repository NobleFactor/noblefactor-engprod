---
title: "Engineering procedures"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Engineering procedures

Procedures explain how to satisfy the shared process. They do not grant authority, replace approvals or weaken standards.

The first review draft retains the [PR procedure](pull-request.md). Open-branch, cleanup, clone retirement, deployment and recovery command procedures will be reconciled against the approved process before publication. Existing commands are not assumed to implement the newly approved decisions.

Compliance checks, GitHub configuration and first-/third-party tool choices are intentionally deferred. Do not replace a documented outcome with a claim that a tool “handles it.”
