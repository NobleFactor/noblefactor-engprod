---
title: "Documentation standards"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Documentation standards

## Form and metadata

Every tracked Markdown document carries frontmatter unless an explicit reviewed exemption applies. Retain the two families: `type` distinguishes catalog documents describing decisions from working documents describing work. Catalog documents require title and type; working documents require title. Preserve the existing allowed type and status vocabularies until separately changed. See [retained metadata detail](../engineering/review/documentation-detail.md).

Plans use draft, approved, active, complete and abandoned. A design's approval does not certify its implementation. Working status, decision approval and delivery milestones communicate different facts.

Use US English in prose and comments. Exceptions address checker errors or intentionally quoted historical material, not preference for other spelling. Document exemptions are named paths, reviewed as decisions rather than hidden in broad patterns.

## Ownership and maintenance

Each requirement has one authoritative home. Cross-reference it rather than restating it in agent prompts, repository instructions and templates. State applicability explicitly. Repository instructions carry local facts and approved variations, naming the shared requirement affected.

The process owns transitions; standards own required asset content and state; procedures own mechanics. Templates introduce no requirements independently. Existing incident histories explain rationale and serve as examples; they must not be necessary to reconstruct current instructions.

Define every new term; use issue for scheduled work. Distinguish the schedule issue from the issues it orders. Full historical text is preserved as source evidence without attempting terminology replacement inside quotes or code examples.

## Links, changes and history

Work assets define issue/plan/design link and path requirements. Prefer stable anchors and identities. Update affected documents in the same commit as the facts change, including implementation-status companions and user-facing material. Distinguish proposed, approved, implemented and verified statements.

When replacing a document, record its successor and migrate incoming references. Retain a clear historical designation for source records; do not leave two active definitions. The publication migration and any compatibility changes to tools are later work requiring review.
