---
title: "Plan template"
status: draft
created: 2026-10-28
updated: 2026-10-29
---

# Plan template

Copy to `docs/plans/<type>/<issue>-<name>.md` after the issue and worktree exist. Replace frontmatter title, retain working-document status, and add issue URL(s), created and updated dates. Commit the plan under applicable approval before implementation; review the committed revision with the owner. This template itself is not an approved implementation plan.

## Role assignments

Identify the [roles](../engineering/process.md#roles-and-responsibilities) for this work, directly or by linking to its schedule's current assignments:

- **Owner:** [accountable engineer].
- **Participants:** [agents/people performing the work and their scope].
- **Reviewers:** [consulted reviewers; identify design, planning, and code responsibilities as applicable].
- **Observers:** [stakeholders to keep informed, or none; link to the role definition above].

## Summary and promised result

[The behavior, implementation and design the owner will have at the end; scope exclusions.]

## Issue NNN

[Actual issue reference and problem. Repeat a number-only heading for every issue in a shared plan.]

## Current state

[Relevant implementation/design, limitations and evidence.]

## Design impact

[Explicit impact determination, affected design links or reasons no change is required.]

## Proposed implementation

[Components, interfaces, algorithms, data/resource changes, file locations, error behavior and relevant rollout/recovery implications.]

## Alternatives and challenges

[Assumptions challenged, alternatives, tradeoffs, disagreements and decisions.]

## Acceptance criteria and evidence

| Criterion | Observable result | Evidence/method | Environment/artifact |
| --- | --- | --- | --- |
| [criterion] | [result] | [check and retained evidence] | [target] |

The plan remains `active` until all agreed completion milestones are satisfied. Record implementation readiness in the final implementation commit; required post-merge deployment or verification keeps the plan active.

## Required completion milestones

| Milestone | Required? | Expected evidence | State/result |
| --- | --- | --- | --- |
| Implementation | [yes/no with rationale] | [revision/review] | Pending |
| Merge | [yes/no with rationale] | [PR/commit] | Pending |
| Deployment | [yes/no with rationale] | [target/artifact] | Pending |
| Verification | [yes/no with rationale] | [acceptance evidence] | Pending |

## Implementation phases

### Phase 1: [name]

- [ ] [Deliverable and verification step.]
- [ ] [Update affected documents in the same commit.]

## Files and related assets

[Create/modify/remove paths; linked issue, designs, status companions and user docs.]

## Dependencies, overlaps and blockers

[Dependency, current state, owner decision, preserved work location.]

## Approval and departures

[Owner approval of exact plan/design revision; proposed and approved departures with effects.]

## Completion review

[Link to results/evidence, outstanding obligations and owner decision or unattended-progression authority. Do not imply that a future merge/deployment has happened.]
