---
title: "Engineering documentation review: findings"
status: draft
created: 2026-10-29
updated: 2026-10-29
---

# Engineering documentation review: findings

A review of the whole draft set on `doc/420-consolidate-engineering`, 2026-10-29: the three main documents, the
index, agent operation, release and recovery, the procedures, the five templates, the standards, the decision
record, the eleven resolved decisions and the migration of the nineteen numbered rules. Findings are the reviewer's;
decisions are the Owner's.

## The set as a whole

The structure is right, and the honesty is unusual: every "deferred" and "not claimed" is where it should be. Two
problems run through all of it.

- **The set states "one authoritative home" and then breaks it.** The documentation-only follow-up PR appears,
  near verbatim, in `process.md`, `work-assets.md` and `procedures/pull-request.md`; one PR per worktree in
  `process.md` and `agent-operation.md`; role assignments as a block at the head of all five templates, where
  they will go stale five times over. Each requirement needs one home and a link from everywhere else.
- **The cases are gone.** The existing documents carry their rulings with dates and the breakage that produced each
  rule. The draft moves all of that into the retained snapshots and leaves abstract policy. The index says incidents
  "remain rationale and regression examples", but no main document cites one. Agents, the main readers, follow
  "ruled 2026-10-22, three commits in one evening" better than "git authority remains an explicit obligation". Keep
  one line of rationale per rule in the main text.

## Engineering process

- **The RACI mapping is inverted for Observer.** Informed is the party who is kept informed; the draft makes
  Observers the ones who inform the Owner. Either Observers are Informed and receive reports, or the role is
  something else and should not borrow the RACI name.
- **"Git authority remains an explicit obligation" says nothing.** Rule 17 is the content: asked for by name,
  granted once, with the bounded grant of O04 as the alternative. State both here.
- **The review step is thinner than the practice.** Today a plan is committed, its questions are ruled one at a
  time, and work starts on "yes" to "Shall I start?". Say that; "substantive owner review" is not a step anyone can
  check.
- **Keep as written:** the departures paragraph, the milestones distinction, "Code is not finished until it reads
  clearly", and "Cleanup does not itself demonstrate deployment".

## Work organization

- **Text defects:** "we works" in the first sentence; "Record a move when work moves, a merge when it lands, and
  another closure with its actual reason" is garbled.
- **Chore is retired as an issue tier by O02 and kept as a branch type in work assets.** Defensible, but it has to
  be said in one place, with the migration of existing chore issues named as its own item.
- **The schedule template renames Lane and Item to Position and Issue.** The report reads columns by position and,
  as found on 2026-10-27, splits a row on an escaped pipe. Both belong on the compatibility list before this header
  ships.
- **Persistent assignments match the session model exactly** and should link to it
  (`docs/architecture/agent-schedule/1-session-model.md`), the document that says what a session, a conversation and
  a schedule store are.

## Work assets

- **Approval records:** the draft proposes "fields". The practice is a dated ruling quoted in the plan, and it works.
  Name that as the approval record rather than invent a field no tool reads.
- **The `## Issue NNN` rule, number only, no title, is new.** Existing shared plans use "## Issue 415: title".
  Either grandfather them or add the migration.
- **Clone retirement is a procedure,** forty lines of mechanics in a document about which records must exist. Move
  it under procedures.
- **The lifecycle paragraph is one block of eleven sentences**, the same text as `process.md`; it should become one
  sentence and a link.
- **An open question the draft does not ask:** do the Owner's personal repositories follow these asset rules? The
  tmux change of 2026-10-29 went in from a branch with no issue, on the Owner's word. Say which rules the personal
  layer keeps.

## The rest

Agent operation reads as the arrangement actually run, a reviewer above and workers below. Release and recovery is
right to refuse the old reset path. The standards defer honestly.

## Before adoption

1. Dedupe to one home per requirement.
2. Restore one line of case to each rule.
3. Fix the Observer mapping.
4. Read the three main documents once more as an agent at session start would, in order, for length.
