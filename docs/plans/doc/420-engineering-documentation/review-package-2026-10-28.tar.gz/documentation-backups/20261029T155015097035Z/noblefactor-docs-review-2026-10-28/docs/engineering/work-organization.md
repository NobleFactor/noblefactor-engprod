---
title: "Work organization"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Work organization

## Work and identity

In a `schedule`, we works to resolve `bug`s and complete `task`s that shape `feature`s. These are defined within the scope of an `epic` in a GitHub repository. We call the bugs and tasks in a schedule `work items`.

Use a repository-qualified reference, `owner/repository#number`, wherever a bare number is ambiguous. A schedule issue is the GitHub issue containing the schedule. It organizes work; it is not one of its own scheduled tasks.

An epic defines a body of work. A feature describes a capability within that scope. Tasks implement parts of it; bugs repair behavior it should already provide. Product and engineering work use the same hierarchy: Epic → Feature → Task/Bug. Distinguish their purpose through the owning epic or area, not a separate chore tier. Most engineering-productivity work is recorded in `NobleFactor/noblefactor-engprod`; other repositories may use their own epic. Recommend an `engprod` epic for engineering-productivity work where appropriate, without requiring that exact name everywhere. Existing chore issues and schedule-container metadata need an explicit migration; this decision does not change GitHub records or commit/branch types. Schedules may draw issues from multiple features, epics and repositories.

A thread describes a scenario whose parts cross features or repositories. It is another view of work, not a unit of execution. Historical issue and thread classification is preserved in [the retained classification text](review/issue-classification.md). Its former chore tier is superseded by O02; GitHub field representation and migration are deferred.

## Schedule commitment

A schedule states its deliverable as before → after: what exists now and what will exist when its issues are complete. It orders repository-qualified task and bug issues and identifies their dependencies. Positions are numbered 1..N without gaps; completed issues retain their positions so the record of progress remains legible.

Once committed, execute the declared order. Adding, splitting, removing or reordering scheduled work, or changing the deliverable, requires owner approval. A blocking discovery does not waive this requirement. Record the approved amendment and its consequences before affected execution resumes.

Keep the current worktree, state, dependencies, PR and completion evidence current as changes occur. Record a move when work moves, a merge when it lands, and another closure with its actual reason. A closed bug/task is not automatically evidence that the promised result was delivered.

The [schedule template](../templates/schedule.md) proposes the record's shape. Column naming and existing report compatibility are review items, not completed tooling changes.

## Changing scheduled work

The process supports changes in the shape of a job. Engineers must be able to create schedules, add work items, log discovered issues for triage, and move work items between schedules in a coordinated fashion. These are normal operations, not evidence of planning failure.

Changes to a committed schedule require Owner approval. Record the proposed change, its effect on the promised outcome and dependencies, and the approval. Update affected plans and schedule records so they describe the revised work rather than preserving an obsolete commitment.

Before transferring a work item, identify its source and destination schedules, execution responsibility, current worktree and state, and any affected dependencies. Coordinate with the affected workers under the approved communication boundaries and keep them informed as the change occurs. Do not leave the work item assigned to two schedules or surprise a worker with a changed mission. Detailed issue-tracking mechanics remain separate tooling work.

## Overlap and coordination

Schedules can overlap. Discovering overlap requires notifying the owner before either worker changes scope, ownership or execution order. State the shared issue or affected code, current owners, dependency and proposed coordination.

No two schedules may contain the same work item. Schedules may overlap in the code, features or dependencies they affect, but that overlap does not permit duplicate work-item membership. A transfer must be coordinated so responsibility is unambiguous and the affected workers are not surprised.

Overlap does not authorize duplicate writes or cross-worker messages. The Owner approves bounded cross-worker conversations under [Agent operation](agent-operation.md). Any resulting mission change requires its own approval.

## Discoveries and blockers

Log discovered work when found and link it from the current plan. State whether it blocks the approved outcome, where it should be handled and what decision is required. New nonblocking work belongs on a later schedule unless an amendment is approved.

A blocker prevents proceeding with approved work; severity or annoyance alone does not establish a blocker. Stop affected work, preserve the worktree and unfinished changes, and record state, evidence and the dependency. Propose whether the blocker needs its own worktree or is inseparable from the current work. Consult the owner before acting on a defect in another worker's or PR's scope.

Do not work around an external blocking defect merely to claim progress. Do not change the running schedule, discard work or take over another worker's responsibility without approval.

## Persistent assignments

An owner-supervised worker receives a schedule as its mission. A persistent session works through that schedule's issues; it is not replaced merely because the next issue begins. Resumption restores the assignment and its current approved state. Terminal lifetime, agent-session lifetime, issue state and work completion are distinct.
