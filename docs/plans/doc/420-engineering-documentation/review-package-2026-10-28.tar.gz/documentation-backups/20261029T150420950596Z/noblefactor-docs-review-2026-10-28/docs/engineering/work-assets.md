---
title: "Work assets"
status: draft
created: 2026-10-28
updated: 2026-10-28
---

# Work assets

## Identity and relationships

Each issue links to its plan and applicable designs. Each plan identifies every issue it serves. A worktree and branch identify their originating issue; a PR identifies the issues and approved changes it delivers. Deployment and verification evidence identify the artifact and environment actually evaluated.

| Asset             | Required content                                                                                                         |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Schedule          | Before/after deliverable, ordered issues, dependencies, current work locations and state, approved amendments            |
| Issue             | Problem, scope, intended outcome, feature/epic relationship, schedule association where applicable, document table       |
| Plan              | Intended implementation, design impact, approved approach, phases, acceptance criteria, required milestones and evidence |
| Design            | Resulting behavior/structure/interfaces, alternatives, tradeoffs and enduring decisions                                  |
| Approval          | Decision, approver, scope and the revision or proposal approved                                                          |
| Completion review | Expected versus observed results, evidence, remaining obligations, owner approval or bounded progression authority       |

Approval records are proposed documentation fields, not an implemented authorization system. Preserve the original conversation/reference; do not fabricate approvals from inferred intent.

## Workspace locations

Use one organization subtree, `~/Workspace/<org>/`. It contains canonical clone entries, issue-named worktrees and their sibling PR scripts. A layer clone lives at `~/.local/share/devlore/writ/repos/<clone>`; its workspace entry is a symlink. Keep one canonical clone per layer, on its default branch. Development branches are checked out in worktrees, not canonical clones.

A worktree is `<clone>.<issue>-<name>`. Its PR script is `<worktree>.bash` on macOS/Linux or `<worktree>.ps1` on Windows. Read an existing script before overwriting; ensure its target is this worktree. Authorization for one script never extends to another worker's script.

Branch types remain `chore`, `doc`, `feature`, `fix`, `hotfix`, `refactor`, `release` pending any separately approved change. The branch identifies its issue; it is created from the repository's default branch through the supported open-branch procedure.

## Plans and designs

Plans live at `docs/plans/<type>/<issue>-<name>.md`, corresponding to the originating branch name. A separately needed plan for an additional issue names that issue. A shared plan carries a stable `## Issue NNN` heading for each issue; use the number alone, with no title or `#` prefix.

Every issue ends with `## Plan and design documents`, a two-column Kind/Document table. It has a plan row from filing, initially “Not yet opened,” and one linked row per applicable design. Add the design-impact determination to the issue and plan, even when no separate design is needed. Document links target committed files on the default branch and stable issue anchors. Before merge, such links may intentionally be pending; provide the review revision separately so approval is possible.

New enduring designs belong under `docs/architecture/` within the owning repository. Existing approved locations remain until individually migrated. This draft proposes no new design filename scheme.

## Lifecycle and freshness

Retain plan status vocabulary: `draft`, `approved`, `active`, `complete`, `abandoned`. Approval and implementation milestones do not mean merge or deployment. Keep incomplete obligations explicit. A plan remains `active` until all agreed completion milestones are satisfied, including required post-merge deployment or verification. The final implementation commit records implementation readiness; it does not prematurely mark the whole plan `complete`. The GitHub issue remains open until all agreed completion milestones are satisfied and completion is approved by the Owner or covered by explicit unattended-progression authorization. A PR references rather than automatically closes an issue when post-merge obligations remain. Record post-merge results immediately on the issue, then incorporate them into the plan through a documentation-only follow-up PR. Validate documentation-only scope, document formatting, metadata and links without rerunning builds, code linting or functional tests. Keep the follow-up obligation visible until incorporation. GitHub configuration and implementation are deferred; this policy does not claim the lightweight path already exists.

Update affected documents in the commit changing the facts they describe: completed phase boxes, architecture/status companions, deleted APIs and paths, and user-facing documentation. A document intentionally retained as history says so.

The [templates](../templates/index.md) provide the proposed required structure. They do not grant approval or make a check true merely because its box is ticked.

## Clone retirement

Before removing a clone, save what origin lacks outside it: uncommitted work, stashes and local commits as patches, and every ref as a bundle. Transfer live worktrees through repair or controlled reopening. Check writ registrations, symlinks and script working directories. Remove only after those steps, under applicable approval, and report what was saved and where.

## Layer script locations

Code contributing to or depending on a repository stack belongs in its named `Home/<repository>[.<selector>]` project. Unconditionally deployed, self-contained code belongs in `Home/common[.<selector>]`. `git-*` commands live beside Declare-BashScript in engprod's common project. Context projects keep their scripts and source the base helper in place. Dependency declarations follow [Bash standards](../standards/coding/bash.md).
